<?php
echo <<<HTML
<div class="cpy">
©Powered by <a href="http://www.14jz.com">钧泽网络</a> 
</div>
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1255856359'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/z_stat.php%3Fid%3D1255856359%26show%3Dpic1' type='text/javascript'%3E%3C/script%3E"));</script>
{$tongji}
HTML;
echo "</html>";
?>
